package com.example.superkomponenty;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class CustomRectangleView extends View {

    private Paint paint;
    private int rectColor = Color.BLUE;
    private Rect rect;
    private int rectLeft = 200;
    private int rectTop = 400;
    private int rectRight = 500;
    private int rectBottom = 600;
    private boolean animating = false;

    public CustomRectangleView(Context context) {
        super(context);
        init();
    }

    public CustomRectangleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setColor(rectColor);
        rect = new Rect(rectLeft, rectTop, rectRight, rectBottom);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawRect(rect, paint);
    }

    public void startRectangleAnimation() {
        if (animating) return;
        animating = true;

        // Kolor zmienia się co 500 ms
        ObjectAnimator colorAnimator = ObjectAnimator.ofArgb(this, "rectColor", Color.BLUE, Color.YELLOW, Color.RED);
        colorAnimator.setDuration(1500);
        colorAnimator.setRepeatCount(ValueAnimator.INFINITE);
        colorAnimator.setRepeatMode(ValueAnimator.RESTART);
        colorAnimator.start();

        // Rozmiar animacji
        ObjectAnimator sizeAnimator = ObjectAnimator.ofInt(this, "rectBottom", rectBottom, rectBottom + 200);
        sizeAnimator.setDuration(1000);
        sizeAnimator.setRepeatCount(ValueAnimator.INFINITE);
        sizeAnimator.setRepeatMode(ValueAnimator.REVERSE);
        sizeAnimator.start();

        // Rotacja animacji
        ObjectAnimator rotationAnimator = ObjectAnimator.ofFloat(this, "rotation", 0f, 360f);
        rotationAnimator.setDuration(2000);
        rotationAnimator.setRepeatCount(ValueAnimator.INFINITE);
        rotationAnimator.setRepeatMode(ValueAnimator.RESTART);
        rotationAnimator.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            startRectangleAnimation();
            return true;
        }
        return super.onTouchEvent(event);
    }

    public void setRectColor(int color) {
        rectColor = color;
        paint.setColor(rectColor);
        invalidate();
    }

    public void setRectBottom(int bottom) {
        rectBottom = bottom;
        rect.bottom = rectBottom;
        invalidate();
    }

    public void setRectLeft(int left) {
        rectLeft = left;
        rect.left = rectLeft;
        invalidate();
    }

    public void setRectRight(int right) {
        rectRight = right;
        rect.right = rectRight;
        invalidate();
    }

    public void setRectTop(int top) {
        rectTop = top;
        rect.top = rectTop;
        invalidate();
    }
}
