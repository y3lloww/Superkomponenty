package com.example.superkomponenty;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.FrameLayout;
import android.view.ViewGroup.LayoutParams;
import android.view.View;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Tworzymy layout główny
        FrameLayout mainLayout = new FrameLayout(this);

        // Tworzymy instancje CustomCircleView i CustomRectangleView
        CustomCircleView customCircleView = new CustomCircleView(this);
        CustomRectangleView customRectangleView = new CustomRectangleView(this);

        // Ustawienia dla customCircleView
        customCircleView.setId(View.generateViewId());
        customCircleView.setLayoutParams(new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        // Ustawienia dla customRectangleView
        customRectangleView.setId(View.generateViewId());
        customRectangleView.setLayoutParams(new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        // Dodanie widoków do layoutu
        mainLayout.addView(customCircleView);
        mainLayout.addView(customRectangleView);

        // Ustawienie głównego layoutu jako widoku głównego aktywności
        setContentView(mainLayout);
    }
}
