package com.example.superkomponenty;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class CustomCircleView extends View {

    private Paint paint;
    private int circleColor = Color.RED;
    private float circleX = 300;
    private float circleY = 300;
    private float radius = 150;
    private boolean animating = false;

    public CustomCircleView(Context context) {
        super(context);
        init();
    }

    public CustomCircleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(circleColor);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawCircle(circleX, circleY, radius, paint);
    }

    public void startCircleAnimation() {
        if (animating) return;
        animating = true;

        // Kolor zmienia się co 500 ms
        ObjectAnimator colorAnimator = ObjectAnimator.ofArgb(this, "circleColor", Color.RED, Color.GREEN, Color.BLUE);
        colorAnimator.setDuration(1500);
        colorAnimator.setRepeatCount(ValueAnimator.INFINITE);
        colorAnimator.setRepeatMode(ValueAnimator.RESTART);
        colorAnimator.start();

        // Rozmiar animacji
        ObjectAnimator sizeAnimator = ObjectAnimator.ofFloat(this, "radius", radius, radius + 100);
        sizeAnimator.setDuration(1000);
        sizeAnimator.setRepeatCount(ValueAnimator.INFINITE);
        sizeAnimator.setRepeatMode(ValueAnimator.REVERSE);
        sizeAnimator.start();

        // Ruch animacji
        ObjectAnimator moveAnimatorX = ObjectAnimator.ofFloat(this, "circleX", circleX, getWidth() - radius);
        moveAnimatorX.setDuration(2000);
        moveAnimatorX.setRepeatCount(ValueAnimator.INFINITE);
        moveAnimatorX.setRepeatMode(ValueAnimator.REVERSE);
        moveAnimatorX.start();

        ObjectAnimator moveAnimatorY = ObjectAnimator.ofFloat(this, "circleY", circleY, getHeight() - radius);
        moveAnimatorY.setDuration(2000);
        moveAnimatorY.setRepeatCount(ValueAnimator.INFINITE);
        moveAnimatorY.setRepeatMode(ValueAnimator.REVERSE);
        moveAnimatorY.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            startCircleAnimation();
            return true;
        }
        return super.onTouchEvent(event);
    }

    public void setRadius(float radius) {
        this.radius = radius;
        invalidate();
    }

    public void setCircleX(float circleX) {
        this.circleX = circleX;
        invalidate();
    }

    public void setCircleY(float circleY) {
        this.circleY = circleY;
        invalidate();
    }

    public void setCircleColor(int color) {
        circleColor = color;
        paint.setColor(circleColor);
        invalidate();
    }
}
